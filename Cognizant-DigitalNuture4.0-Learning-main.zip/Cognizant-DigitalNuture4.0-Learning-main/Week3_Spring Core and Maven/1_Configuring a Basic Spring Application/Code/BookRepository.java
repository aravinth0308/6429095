package com.library.repository;

public class BookRepository {
    public String getBookTitle() {
        return "Effective Java";
    }
}
